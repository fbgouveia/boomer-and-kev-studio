# Continuidade do projeto — 05/09/2026

Comece pelo bloco atual do [HANDOFF único](boomer-and-kev-studio/HANDOFF.md), até `CONTINUIDADE_ATUAL_FIM`.
Registre ali pendências, atualizações e descobertas. Handoffs alternativos,
`progress.md`, `findings.md` e planos antigos são histórico sob demanda.
Esta regra supera hierarquias antigas de leitura. As leis FGSS e o roteamento
canônico determinam a proporcionalidade de Karpathy, VLAEG e Ponytail.
Dados de disponibilidade e provedores datados abaixo precisam ser revalidados
quando forem usados, sem repetir essa pesquisa para simples retomada documental.

---

# CLAUDE.md — Diretrizes de Desenvolvimento e Comandos

Este arquivo serve como guia de referência rápida de comandos e políticas de desenvolvimento para este projeto.

## 🚀 COMANDOS DO PROJETO
- **Iniciar servidor de desenvolvimento:** `npm run dev` (dentro de `boomer-and-kev-studio/`)
- **Compilar o projeto:** `npm run build` (dentro de `boomer-and-kev-studio/`)
- **Executar Linter:** `npm run lint` (dentro de `boomer-and-kev-studio/`)
- **Checagem de Tipos (TypeScript):** `npx tsc --noEmit` (dentro de `boomer-and-kev-studio/`)
- **Concatenação de clipes de vídeo (FFmpeg):** `node tools/assemble.mjs` (dentro de `boomer-and-kev-studio/`)

---

## 🎨 DIRETRIZES DE DESIGN (UI/UX)
Siga a lei de design em `/Users/felipegouveia/Developer/CÉREBRO/LEIS_FGSS.md`: Open Design produz e o Gestor pertinente aprova. As referências visuais abaixo não substituem essa regra.
- Cor primária: `#FF5F1F` (Signal Orange).
- Fundo: `#000000` / `#0d0d0d`.
- Estilo: Brutalist Neural Glass (bordas sólidas de 4px laranja, overlays HUD com blur).
- **Proibido:** Qualquer tom de roxo/violeta.

---

## ⚖️ FILOSOFIA DE DESENVOLVIMENTO

### 🧠 KARPATHY (Sempre Ligado)
1. **Pensar antes de codar:** Declarar suposições e perguntar ao Felipe antes de fazer escolhas em silêncio.
2. **Simplicidade primeiro:** Fazer o mínimo necessário para resolver o problema.
3. **Mudanças cirúrgicas:** Tocar apenas no necessário, mantendo o restante intocado.
4. **Meta verificável:** Ter um critério de teste claro antes de executar alterações.

### 🚀 VLAEG (Automação)
- Seguir o fluxo: **Visão → Link → Arquitetura → Estilo → Gatilho**.
- **Protocolo 0:** Sempre definir/confirmar o schema de dados antes de iniciar o código.

### ✅ HONESTIDADE
- Sem métricas inventadas ou números artificiais.
- Relatar falhas exatamente com a saída real do terminal/logs.

### 🐎 PONYTAIL (Nível `full` ativo por padrão)
- **YAGNI:** Não construa o que não foi expressamente pedido.
- **Standard Library:** Dar preferência a recursos nativos em vez de adicionar dependências desnecessárias.
- **Mínimo de Boilerplate:** Simplificar o código ao máximo. Se couber em uma linha, use uma linha.
- **Comentários de atalho:** Marque atalhos técnicos com o comentário `ponytail:`.
