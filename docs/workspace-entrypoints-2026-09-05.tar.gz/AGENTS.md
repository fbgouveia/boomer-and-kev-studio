# Boomer & Kev — entrada única do workspace

A raiz deste projeto é esta pasta: `PROJETOBoomer and Kev`.

1. Leia as leis em `/Users/felipegouveia/Developer/CÉREBRO/LEIS_FGSS.md` e as regras
   canônicas em `/Users/felipegouveia/Developer/CÉREBRO/FGSS brain/AGENTS.md` e
   `fgss-brain.json`. Classifique cada tarefa com o roteador desse diretório.
2. Para retomar o projeto, leia **somente o bloco atual de [HANDOFF.md](HANDOFF.md)**,
   até `CONTINUIDADE_ATUAL_FIM`. Ele reúne pendências, atualizações e descobertas.
   Histórico é consulta pontual; checkboxes antigos não são tarefas atuais.
3. `HANDOFF.md` é um link para o arquivo versionado no Studio. Ao salvar, edite
   `BOOMER AND KEV/boomer-and-kev-studio/HANDOFF.md` e preserve o link da raiz.
   A política de continuidade está nesse arquivo; não mantenha cópias paralelas.
4. Consulte [README.md](README.md) para comandos e mapa das pastas. O Git e o
   aplicativo estão em `BOOMER AND KEV/boomer-and-kev-studio`; os demais diretórios
   são mídias, referências ou histórico. Não iniciar outro aplicativo na raiz.
5. Preserve alterações preexistentes. O pedido de consolidação documental não
   autoriza alterações no core, renders pagos, publicação ou movimentação das mídias.

Para ler apenas a continuidade atual no terminal:

```sh
sed -n '1,/<!-- CONTINUIDADE_ATUAL_FIM -->/p' HANDOFF.md
```
