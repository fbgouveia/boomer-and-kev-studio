# Boomer & Kev — projeto unificado

## Retomar o projeto

Abra sempre esta pasta, **PROJETOBoomer and Kev**, e leia o [HANDOFF único](HANDOFF.md).
O bloco inicial reúne **pendências, atualizações e descobertas** de todo o projeto.
O histórico fica abaixo, para consulta eventual. As [instruções de entrada](AGENTS.md)
orientam os agentes a usar a mesma fonte.

O arquivo da raiz é um link para o handoff versionado do Studio: ambos abrem e
atualizam o mesmo conteúdo. Código e mídias mantêm seus caminhos existentes.

## Abrir o Studio

Na pasta deste arquivo:

```sh
npm run dev
```

Acesse **http://127.0.0.1:3000**. O comando usa a instalação existente em
`BOOMER AND KEV/boomer-and-kev-studio`, com acesso somente pelo próprio computador.
Não é necessário instalar dependências novamente na raiz.

O navegador pede Basic Auth. Usuário e senha são `STUDIO_AUTH_USER` e
`STUDIO_AUTH_PASSWORD` do `.env.local` do aplicativo. Não compartilhar esses valores
em chat, links ou screenshots. HTTP 401 sem credenciais é a proteção esperada.

Se o Chrome mostrar `ERR_BLOCKED_BY_CLIENT`, o erro é do cliente/navegador.
Confirme o diagnóstico abaixo; não remova a autenticação, o firewall ou políticas
do navegador para contorná-lo. A extensão pode precisar de intervenção do operador.

## Diagnóstico sem gerar conteúdo pago

```sh
npm run check:connections
```

Verifica o Studio, imagens, notícias e acesso de leitura aos provedores. Não gera
voz/vídeo, não publica e não escreve no banco. `LIMITED` significa que a consulta
não foi autorizada pelo escopo da chave; não prova que geração esteja indisponível.
`UNCONFIGURED` identifica variáveis ausentes, sem inventar configuração.

## Pastas

| Pasta | Uso |
|---|---|
| `BOOMER AND KEV/boomer-and-kev-studio` | Aplicativo, API, testes e configuração ativa |
| `boomer-and-kev-studio/public/assets` | Estrutura antiga vazia; não contém aplicativo |
| `BOOMER AND KEV/00_Legacy_Archives` | Pilotos, vídeos e projetos antigos |
| `BOOMER AND KEV/01_Pre_Production` | Roteiros, storyboards e áudio |
| `BOOMER AND KEV/02_Production` | Referências, prompts e renders |
| `BOOMER AND KEV/03_Post_Production` | Premiere, legendas e efeitos sonoros |
| `BOOMER AND KEV/04_Delivery` | Entregáveis de mídia |
| `.playwright-mcp` | Evidências históricas de navegador |

Existe apenas um aplicativo ativo. A segunda pasta Studio é vazia e não deve ser
usada como projeto. O Git permanece dentro do aplicativo; esta raiz é a entrada
unificada do workspace e já oferece os comandos de desenvolvimento acima.

`HANDOFF_AMANHA.md`, `HANDOFF_VLAEG.md`, `progress.md`, `findings.md` e os planos
antigos são histórico. Não há rotina de atualizar ou revisar essas listas em
paralelo. Registre a continuidade apenas no bloco atual do [HANDOFF.md](HANDOFF.md).
O registro externo que antes ocupava o handoff da raiz foi preservado no histórico,
com valores de segredo removidos da documentação.
